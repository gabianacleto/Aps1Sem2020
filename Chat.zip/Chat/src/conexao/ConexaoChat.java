package conexao;

import java.sql.Connection;
import java.sql.*;
import java.util.logging.Level;
import java.util.logging.Logger;


/**
 *
 * @author Gabriela
 */
public class ConexaoChat {
    
    //Criando conexao

  //  private static final String URLSQLITE = "jdbc:sqlite:chat.db";
    
    public static Connection getConnection(){
    try{
       Class.forName("org.sqlite.JDBC"); 
       Connection con = DriverManager.getConnection("jdbc:sqlite:chat.db");
       System.out.println("Conexão ok");
       return con;
        
    }
    catch(SQLException e ){
        System.out.println(e.getMessage());
    }   catch (ClassNotFoundException ex) {
            Logger.getLogger(ConexaoChat.class.getName()).log(Level.SEVERE, null, ex);
        }
        return null;
    
  }
    
    //fechando conexao
    
    public static void closeConnect(Connection con ){
        
            try {
                if(con != null){
                con.close();
                    System.out.println("Conexão encerrada");
                 } 
            } catch (SQLException ex) {
                Logger.getLogger(ConexaoChat.class.getName()).log(Level.SEVERE, null, ex);
            }
        }  
    
    //sobrecarga
     public static void closeConnect(Connection con, PreparedStatement stmt ){
        
         closeConnect(con);
         
         try {
              if(stmt !=null){
                  stmt.close();
              }  
            } catch (SQLException ex) {
                Logger.getLogger(ConexaoChat.class.getName()).log(Level.SEVERE, null, ex);
            }
        }  
        
   //sobrecarga
     public static void closeConnect(Connection con, PreparedStatement stmt, ResultSet rs ){
        
         closeConnect(con, stmt);
         
         try {
              if(rs !=null){
                  rs.close();
              }  
            } catch (SQLException ex) {
                Logger.getLogger(ConexaoChat.class.getName()).log(Level.SEVERE, null, ex);
            }
        }  
     
     public static void main(String[] args) {
        getConnection();
    }

    
}
