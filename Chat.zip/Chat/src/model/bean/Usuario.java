/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model.bean;

/**
 *
 * @author Gabriela
 */
public class Usuario {
    private int cd_usuario;
    private String nm_user;
    private String ds_mensagens;
    private String cd_login;
    private String cd_senha;

    public int getCd_usuario() {
        return cd_usuario;
    }

    public void setCd_usuario(int cd_usuario) {
        this.cd_usuario = cd_usuario;
    }

    public String getNm_user() {
        return nm_user;
    }

    public void setNm_user(String nm_user) {
        this.nm_user = nm_user;
    }

    public String getDs_mensagens() {
        return ds_mensagens;
    }

    public void setDs_mensagens(String ds_mensagens) {
        this.ds_mensagens = ds_mensagens;
    }

    public String getCd_login() {
        return cd_login;
    }

    public void setCd_login(String cd_login) {
        this.cd_login = cd_login;
    }

    public String getCd_senha() {
        return cd_senha;
    }

    public void setCd_senha(String cd_senha) {
        this.cd_senha = cd_senha;
    }
    
    
}
