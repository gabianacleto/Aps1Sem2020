/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model.dao;

import conexao.ConexaoChat;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import model.bean.Usuario;


/**
 *
 * @author Gabriela
 */
public class UsuarioDAO {
    //CRUD
    public void salvarMensagem(Usuario u ){
       
      Connection con = ConexaoChat.getConnection();
      PreparedStatement stmt = null;
      
        try {
            stmt = con.prepareStatement("INSERT INTO usuario (ds_mensagens) VALUES ()");
            stmt.setString(0, u.getDs_mensagens());
            
            stmt.executeUpdate();
            
            System.out.println("Salvo!");
            
        } catch (SQLException ex) {
            System.out.println("Salvo!");
        }finally{
            ConexaoChat.closeConnect(con, stmt );
        }
      
      
       
       
        
    }
}
