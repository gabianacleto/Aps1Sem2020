
package email;

import org.apache.commons.mail.DefaultAuthenticator;
import org.apache.commons.mail.EmailAttachment;
import org.apache.commons.mail.EmailException;
import org.apache.commons.mail.MultiPartEmail;

/**
 *
 * @author Gabriela
 */
public class Email {

    /**
     * @param args the command line arguments
     */
    
    public void enviar (String caminho, String arquivo, String nomeArq){
        
        //config email 
        
        MultiPartEmail email = new MultiPartEmail();
        email.setHostName("smtp.gmail.com");
        email.setSslSmtpPort("465");
        email.setStartTLSRequired(true);
        email.setStartTLSEnabled(true);
        email.setSSLOnConnect(true);
        
        //endereco 
        
        email.setAuthenticator(new DefaultAuthenticator("projetoaps2020@gmail.com", "aps5sem2020"));
        try{
            email.setFrom("projetoaps2020@gmail.com");
            //atributos do email
            email.setSubject("Relatorio de Update - APS2020");
            email.setMsg("Ultima atualização.");
            email.addTo("relatorio.aps2020@gmail.com");
            
            //anexando arquivo
            EmailAttachment attachment = new EmailAttachment();
            attachment.setPath(caminho);
            attachment.setDisposition(EmailAttachment.ATTACHMENT);
            attachment.setDescription(arquivo);
            attachment.setName(nomeArq);
            
                email.attach(attachment);
                email.send();
                
        }catch(EmailException e){
            e.printStackTrace();
        }       
        
        
    }
    
}
